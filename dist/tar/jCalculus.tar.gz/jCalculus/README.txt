==========================================================================	
			jCalculus - Mathematical Calculus Package
==========================================================================
	jCalculus by created by Maheshwaran.S of Sona College of Technology, B.E III Year CSE. jCalculus, is Prolog + Java interface package. The calculus source is written in Prolog and it is interfaced using gnuprolog, with Java.

email: smahesh_monu@rediffmail.com or mahesh_cse@ieee.org
web: http://microprogrammers.150m.com

�

Source Package:
---------------
	The jCalculus source is provided under the GNU public license. Read the license for more details.

	/src 	---> source files
	/lib 	---> library files
	/docs 	---> JavaDoc
	/jar 	---> Binary File

Installing:
-----------
	* Extract the jCalculus.tar or jCalculus.zip to any of the location say C:\
	
Running:
-------
	* To run the jCalculus from the jar file just simply execute the batch file.